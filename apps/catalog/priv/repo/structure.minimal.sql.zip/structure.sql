BEGIN TRANSACTION;

CREATE TABLE IF NOT EXISTS food_group (
  id  SERIAL,
  name  text NOT NULL,
  PRIMARY KEY(id)
);

CREATE TABLE IF NOT EXISTS food (
  id  SERIAL,
  food_group_id int NOT NULL,
  long_desc text NOT NULL DEFAULT NULL,
  short_desc  text NOT NULL DEFAULT NULL,
  common_names  text DEFAULT NULL,
  manufac_name  text DEFAULT NULL,
  survey  text DEFAULT NULL,
  ref_desc  text DEFAULT NULL,
  refuse  int,
  sci_name  text DEFAULT NULL,
  nitrogen_factor float,
  protein_factor  float,
  fat_factor  float,
  calorie_factor  float,
  PRIMARY KEY(id),
  FOREIGN KEY(food_group_id) REFERENCES food_group(id)
);

CREATE TABLE IF NOT EXISTS weight (
	food_id	int NOT NULL,
	sequence_num	int NOT NULL,
	amount	float NOT NULL,
	description	text NOT NULL,
	gm_weight	float NOT NULL,
	num_data_pts	int,
	std_dev	float,
	PRIMARY KEY(food_id,sequence_num)
);

CREATE TABLE IF NOT EXISTS nutrient (
  id  SERIAL,
  units text NOT NULL,
  tagname text DEFAULT NULL,
  name  text NOT NULL,
  num_decimal_places  text NOT NULL,
  sr_order  int NOT NULL,
  PRIMARY KEY(id)
);

CREATE TABLE IF NOT EXISTS nutrition (
  food_id int NOT NULL,
  nutrient_id int NOT NULL,
  amount  float NOT NULL,
  num_data_points int NOT NULL,
  std_error float,
  source_code text NOT NULL,
  derivation_code text,
  reference_food_id TEXT,
  added_nutrient  text,
  num_studients int,
  min float,
  max float,
  degrees_freedom int,
  lower_error_bound float,
  upper_error_bound float,
  comments  text,
  modification_date text,
  confidence_code text,
  PRIMARY KEY(food_id,nutrient_id)
);

CREATE TABLE IF NOT EXISTS common_nutrient (
  id  SERIAL,
  PRIMARY KEY(id)
);


COMMIT;
